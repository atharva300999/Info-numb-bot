# 🚀 Render Deployment Guide

Complete step-by-step guide to deploy your Telegram bot to Render.com

## Step 1: Prepare Your Code

1. Download the bot files (zip)
2. Extract to a folder
3. Create a GitHub account if you don't have one

## Step 2: Push to GitHub

1. **Initialize Git:**
```bash
cd telegram-bot
git init
git add .
git commit -m "Initial commit: Telegram phone lookup bot"
git branch -M main
```

2. **Create GitHub Repository:**
   - Go to [github.com/new](https://github.com/new)
   - Name: `telegram-bot` (or any name)
   - Click "Create repository"

3. **Push Code:**
```bash
git remote add origin https://github.com/YOUR_USERNAME/telegram-bot.git
git push -u origin main
```

## Step 3: Create Render Account

1. Go to [render.com](https://render.com)
2. Sign up (use GitHub for easy login)
3. Authorize GitHub

## Step 4: Create Web Service

1. Click "New +" button (top right)
2. Select "Web Service"
3. Connect to GitHub account
4. Find and select `telegram-bot` repository
5. Click "Connect"

## Step 5: Configure Deployment

Fill in the form:

| Field | Value |
|-------|-------|
| **Name** | `telegram-bot` |
| **Runtime** | Python 3 |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `python main.py` |
| **Instance Type** | Free (or paid) |

Click "Create Web Service"

## Step 6: Add Environment Variables

1. After service is created, go to **Environment** tab
2. Click "Add Environment Variable"
3. Add each variable:

```
BOT_TOKEN = 8687426758:AAE6zG4ooxuvEHZQ8gHhiXZrEGu3D9p3MqY
API_ENDPOINT = https://electron-cursed.vercel.app/lookup
API_KEY = @ElectronCursed
ADMIN_IDS = 8817422430
UPTIME_ROBOT_URL = (optional - leave blank if not using)
```

**Important:** 
- Copy exact values from your `.env` file
- For `ADMIN_IDS` with multiple admins: `8817422430,1234567890`
- Leave `UPTIME_ROBOT_URL` empty if not using Uptime Robot

## Step 7: Set Python Version (Optional but Recommended)

1. At bottom of Environment tab, find "Native Environment"
2. If shows Python version, ensure it's 3.9+
3. Save changes

## Step 8: Deploy

1. Click "Deploy" button
2. Monitor the deployment:
   - You'll see build logs
   - Installation will take 2-3 minutes
   - Bot will start automatically

3. Check status:
   - When green and says "Live", deployment is complete
   - You should see "Render Cloud Run" link (your bot URL)

## Step 9: Test Bot

1. Open Telegram
2. Send `/start` to your bot
3. Try sending a phone number
4. If works, congratulations! 🎉

## Step 10: Get Uptime Robot URL (Optional)

If you want to use Uptime Robot monitoring:

1. Go to [uptimerobot.com](https://uptimerobot.com)
2. Sign up / Log in
3. Click "Add New Monitor"
4. Select type: **Webhook**
5. Copy the webhook URL
6. Go back to Render → Environment
7. Add/update `UPTIME_ROBOT_URL` with the webhook
8. Render will auto-restart with new variable

## Troubleshooting

### Bot still not working after deployment

1. Check Render logs:
   - Go to "Logs" tab in Render
   - Look for errors
   - Common issues: Missing variables, wrong token

2. Verify bot token:
   - Copy your exact bot token from BotFather
   - Check no extra spaces
   - Add to environment

3. Check GitHub push:
   - Render auto-deploys on GitHub push
   - If changed files, push again:
   ```bash
   git add .
   git commit -m "Update config"
   git push
   ```

### Bot goes down after deployment

1. Click "Redeploy" in Render
2. Check if free tier hit usage limit
3. Upgrade to paid plan if needed

### Admin panel not working

1. Get your Telegram ID: Send `/start` to @userinfobot
2. Update `ADMIN_IDS` in Render environment
3. Restart service

### Phone lookup returns error

1. Check API endpoint is correct
2. Verify API key
3. Test with valid Indian number (919696467355)

### Force join not working

1. Ensure channel ID is negative: `-1001234567890`
2. Bot must be admin in channel
3. Verify invite link is public

## Useful Commands

```bash
# Check if bot is running locally
python main.py

# Test environment variables
python -c "from config import BOT_TOKEN; print(f'Token: {BOT_TOKEN[:20]}...')"

# View Render logs
# Use Render dashboard Logs tab
```

## Important Notes

⚠️ **Do NOT commit .env file to GitHub**
- Only commit `.env.example`
- Add `.env` to `.gitignore`
- Set actual values in Render environment

🔐 **Keep bot token secret**
- Never share your `BOT_TOKEN`
- If compromised, regenerate in BotFather
- Remove old token from Render

📊 **Monitor your bot**
- Check Render logs regularly
- Set up Uptime Robot for alerts
- Get admin notifications for errors

## Next Steps

1. ✅ Deploy successful
2. Add more features as needed
3. Customize messages and emojis
4. Add more channels to force join
5. Monitor performance in Render dashboard

---

**Need help?**
- Render Docs: [render.com/docs](https://render.com/docs)
- Telegram Bot Docs: [core.telegram.org/bots](https://core.telegram.org/bots)
- Python Telegram Docs: [python-telegram-bot.readthedocs.io](https://python-telegram-bot.readthedocs.io)

Good luck, baby! 6767
